from __future__ import annotations

from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models.execution import Execution
from app.models.flow_event import FlowEvent
from app.models.goal import Goal
from app.models.outcome import Outcome
from app.services.serializer_service import serialize_outcome_for_workspace


def _safe_dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def build_workspace_items(
    db: Session,
    *,
    goal_type: str | None = None,
    status: str | None = None,
    stage: str | None = None,
    risk_level: str | None = None,
) -> list[dict[str, Any]]:
    stmt = select(Goal).order_by(Goal.id.desc())
    goals = db.execute(stmt).scalars().all()

    items: list[dict[str, Any]] = []

    for goal in goals:
        if goal_type and goal.goal_type != goal_type:
            continue
        if risk_level and goal.risk_level != risk_level:
            continue

        latest_outcome = db.execute(
            select(Outcome)
            .where(Outcome.goal_id == goal.id)
            .order_by(Outcome.id.desc())
            .limit(1)
        ).scalar_one_or_none()

        if status and latest_outcome and latest_outcome.status != status:
            continue

        parsed_goal = _safe_dict(goal.parsed_goal)
        current_result = _safe_dict(latest_outcome.current_result) if latest_outcome else {}
        next_action = _safe_dict(latest_outcome.next_action) if latest_outcome else {}

        current_stage = current_result.get("stage")
        if stage and current_stage != stage:
            continue

        flow_event_count = db.execute(
            select(func.count(FlowEvent.id)).where(FlowEvent.outcome_id == latest_outcome.id)
        ).scalar() if latest_outcome else 0

        execution_count = db.execute(
            select(func.count(Execution.id)).where(Execution.outcome_id == latest_outcome.id)
        ).scalar() if latest_outcome else 0

        step_type = (
            next_action.get("step_type")
            or parsed_goal.get("intent")
            or "unknown"
        )

        title = (
            latest_outcome.title
            if latest_outcome and latest_outcome.title
            else parsed_goal.get("target")
            or goal.raw_input
        )

        items.append(
            {
                "goal_id": goal.id,
                "title": title,
                "goal_type": goal.goal_type,
                "risk_level": goal.risk_level,
                "scope": parsed_goal.get("scope", "unspecified"),
                "parser_meta": parsed_goal.get("parser_meta"),
                "stage": current_stage,
                "step_type": step_type,
                "execution_hint_available": True,
                "executor_touched": bool(execution_count),
                "executor_result_available": bool(execution_count),
                "recommendation_reason_available": True,
                "flow_event_count": int(flow_event_count or 0),
                "created_at": goal.created_at,
                "updated_at": latest_outcome.updated_at if latest_outcome else goal.created_at,
                "latest_outcome": serialize_outcome_for_workspace(latest_outcome),
            }
        )

    return items
