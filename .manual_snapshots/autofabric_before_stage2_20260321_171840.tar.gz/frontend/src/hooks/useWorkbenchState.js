import { useEffect, useState } from "react";
import { STORAGE_KEYS } from "../constants/storageKeys";

function readJson(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function writeJson(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {}
}

export default function useWorkbenchState() {
  const [input, setInput] = useState("");
  const [recentInputs, setRecentInputs] = useState([]);
  const [hasInputDraft, setHasInputDraft] = useState(false);
  const [notice, setNotice] = useState("");

  useEffect(() => {
    const savedDraft = localStorage.getItem(STORAGE_KEYS.INPUT_DRAFT) || "";
    const savedRecent = readJson(STORAGE_KEYS.RECENT_INPUTS, []);
    setInput(savedDraft);
    setHasInputDraft(Boolean(savedDraft.trim()));
    if (Array.isArray(savedRecent)) {
      setRecentInputs(savedRecent.slice(0, 8));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.INPUT_DRAFT, input);
    setHasInputDraft(Boolean(String(input || "").trim()));
  }, [input]);

  useEffect(() => {
    writeJson(STORAGE_KEYS.RECENT_INPUTS, recentInputs.slice(0, 8));
  }, [recentInputs]);

  function flash(message) {
    setNotice(message);
    setTimeout(() => setNotice(""), 1800);
  }

  function clearInputDraft() {
    setInput("");
    setHasInputDraft(false);
    localStorage.setItem(STORAGE_KEYS.INPUT_DRAFT, "");
    flash("已清空输入草稿");
  }

  function restoreInputDraft() {
    const raw = localStorage.getItem(STORAGE_KEYS.INPUT_DRAFT) || "";
    setInput(raw);
    setHasInputDraft(Boolean(raw.trim()));
    flash(raw.trim() ? "已恢复上一份草稿" : "没有可恢复的草稿");
  }

  function saveCurrentDraftToRecent() {
    const trimmed = String(input || "").trim();
    if (!trimmed) {
      flash("当前草稿为空，无法加入最近提交");
      return;
    }
    const next = [trimmed, ...recentInputs.filter((x) => x !== trimmed)].slice(0, 8);
    setRecentInputs(next);
    flash("已加入最近提交");
  }

  function replaceCurrentDraftWithRecent(value) {
    const next = String(value || "");
    setInput(next);
    localStorage.setItem(STORAGE_KEYS.INPUT_DRAFT, next);
    setHasInputDraft(Boolean(next.trim()));
    flash("已用最近提交替换当前草稿");
  }

  return {
    input,
    setInput,
    recentInputs,
    setRecentInputs,
    hasInputDraft,
    notice,
    flash,
    clearInputDraft,
    restoreInputDraft,
    saveCurrentDraftToRecent,
    replaceCurrentDraftWithRecent,
  };
}
