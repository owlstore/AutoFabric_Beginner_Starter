import GoalInputPanel from "../components/header/GoalInputPanel";
import StatsCard from "../components/common/StatsCard";
import OutcomeListPanel from "../components/sidebar/OutcomeListPanel";
import OutcomeOverviewPanel from "../components/overview/OutcomeOverviewPanel";
import OpenClawWorkspaceV2 from "../components/openclaw/OpenClawWorkspaceV2";
import RecordTabsPanelV2 from "../components/records/RecordTabsPanelV2";
import RecordContentPanelV2 from "../components/records/RecordContentPanelV2";
import HealthBanner from "../components/summary/HealthBanner";
import TestSummaryCard from "../components/summary/TestSummaryCard";
import DeliverySummaryCard from "../components/summary/DeliverySummaryCard";
import useWorkbenchState from "../hooks/useWorkbenchState";
import useWorkspaceData from "../hooks/useWorkspaceData";
import useOpenClawState from "../hooks/useOpenClawState";
import useUIPreferences from "../hooks/useUIPreferences";
import useSystemHealth from "../hooks/useSystemHealth";
import { useToast } from "../context/ToastContext";
import { buildDeliveryMarkdown, downloadJson, downloadMarkdown } from "../utils/exporters";
import { useState } from "react";

export default function WorkbenchPageV2() {
  const toast = useToast();

  const {
    input,
    setInput,
    recentInputs,
    setRecentInputs,
    hasInputDraft,
    notice,
    flash,
    clearInputDraft,
    restoreInputDraft,
    saveCurrentDraftToRecent,
    replaceCurrentDraftWithRecent,
  } = useWorkbenchState();

  const { health, loadHealth } = useSystemHealth();

  const {
    submitting,
    quickFilter,
    setQuickFilter,
    searchText,
    setSearchText,
    statusFilter,
    setStatusFilter,
    goalTypeFilter,
    setGoalTypeFilter,
    sortOrder,
    setSortOrder,
    activeCardId,
    setActiveCardId,
    goalCandidates,
    expandedFields,
    setExpandedFields,
    stats,
    detailData,
    listLoading,
    detailLoading,
    listError,
    detailError,
    filteredCards,
    activeDetail,
    loadList,
    loadDetail,
    handleSubmit,
    continueFromCurrentOutcome,
    generateGoalCandidates,
    applyGoalCandidate,
    refreshWorkbench,
    refreshCurrentDetailOnly,
  } = useWorkspaceData({
    input,
    setInput,
    clearInputDraft,
    toast,
  });

  const {
    selectedTemplateId,
    setSelectedTemplateId,
    openclawUrl,
    setOpenclawUrl,
    openclawIssue,
    setOpenclawIssue,
    openclawAccountHint,
    setOpenclawAccountHint,
    openclawNotice,
    setOpenclawNotice,
    hasOpenclawDraft,
    openclawExecuting,
    latestOpenclawSummary,
    recentOpenclawExecutions,
    restoreLastOpenClawDraft,
    resetOpenClawFields,
    clearOpenClawFields,
    handleOpenClawExecute,
  } = useOpenClawState({
    detailData,
    activeCardId,
    loadDetail,
    loadList,
    refreshCurrentDetailOnly,
    toast,
  });

  const [activeTab, setActiveTab] = useState("timeline");

  useUIPreferences({
    activeCardId,
    setActiveCardId,
    activeTab,
    setActiveTab,
    quickFilter,
    setQuickFilter,
    searchText,
    setSearchText,
    statusFilter,
    setStatusFilter,
    goalTypeFilter,
    setGoalTypeFilter,
    sortOrder,
    setSortOrder,
  });

  async function copyText(value, label) {
    try {
      await navigator.clipboard.writeText(String(value || ""));
      flash(`${label} 已复制`);
      toast.success(`${label} 已复制`);
    } catch {
      toast.error(`${label} 复制失败`);
    }
  }

  function saveCandidateToRecent(candidate) {
    const trimmed = String(candidate || "").trim();
    if (!trimmed) return;
    setRecentInputs((prev) => [trimmed, ...prev.filter((x) => x !== trimmed)].slice(0, 8));
    toast.success("候选目标已加入最近提交");
  }

  function exportCurrentResultJson() {
    if (!detailData || !activeDetail) {
      toast.warning("当前没有可导出的结果。");
      return;
    }
    const filename = `autofabric_goal_${activeDetail.goalId}_outcome_${activeDetail.outcomeId}.json`;
    downloadJson(filename, detailData);
    toast.success("已导出当前结果 JSON。");
  }

  function exportDeliveryMarkdown() {
    if (!detailData || !activeDetail) {
      toast.warning("当前没有可导出的交付摘要。");
      return;
    }
    const filename = `autofabric_delivery_goal_${activeDetail.goalId}_outcome_${activeDetail.outcomeId}.md`;
    const markdown = buildDeliveryMarkdown(detailData);
    downloadMarkdown(filename, markdown);
    toast.success("已导出交付摘要 Markdown。");
  }

  async function copyDeliverySummary() {
    if (!detailData) {
      toast.warning("当前没有可复制的交付摘要。");
      return;
    }
    try {
      const markdown = buildDeliveryMarkdown(detailData);
      await navigator.clipboard.writeText(markdown);
      toast.success("交付摘要已复制。");
    } catch {
      toast.error("交付摘要复制失败。");
    }
  }

  const timelineItems = detailData?.flow_events || [];
  const executionItems = detailData?.executions || [];
  const artifactItems = detailData?.artifacts || [];
  const verificationItems = detailData?.verifications || [];

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900">
      <div className="mx-auto max-w-[1440px] px-6 py-6">
        <HealthBanner health={health} onRefresh={loadHealth} />

        <GoalInputPanel
          input={input}
          setInput={setInput}
          submitting={submitting}
          handleSubmit={handleSubmit}
          clearInputDraft={clearInputDraft}
          restoreInputDraft={restoreInputDraft}
          saveCurrentDraftToRecent={saveCurrentDraftToRecent}
          hasInputDraft={hasInputDraft}
          recentInputs={recentInputs}
          replaceCurrentDraftWithRecent={replaceCurrentDraftWithRecent}
          notice={notice}
        />

        <div className="mb-6 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          <StatsCard label="结果总数" value={stats.total} />
          <StatsCard label="已完成" value={stats.completed} tone="success" />
          <StatsCard label="执行中" value={stats.running} tone="info" />
          <StatsCard label="失败" value={stats.failed} tone="danger" />
        </div>

        {listError ? (
          <div className="mb-4 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            左侧结果清单加载失败：{listError}
          </div>
        ) : null}

        {detailError ? (
          <div className="mb-4 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            右侧结果详情加载失败：{detailError}
          </div>
        ) : null}

        <div className="grid grid-cols-1 gap-6 xl:grid-cols-[380px_minmax(0,1fr)]">
          <OutcomeListPanel
            cards={filteredCards}
            quickFilter={quickFilter}
            setQuickFilter={setQuickFilter}
            searchText={searchText}
            setSearchText={setSearchText}
            statusFilter={statusFilter}
            setStatusFilter={setStatusFilter}
            goalTypeFilter={goalTypeFilter}
            setGoalTypeFilter={setGoalTypeFilter}
            sortOrder={sortOrder}
            setSortOrder={setSortOrder}
            activeCardId={activeCardId}
            setActiveCardId={setActiveCardId}
            loading={listLoading}
          />

          <div className="space-y-6">
            {detailLoading ? (
              <div className="rounded-3xl border border-slate-200 bg-white p-8 text-sm text-slate-500 shadow-sm">
                正在加载结果详情...
              </div>
            ) : (
              <>
                <OutcomeOverviewPanel
                  detail={activeDetail}
                  expandedFields={expandedFields}
                  setExpandedFields={setExpandedFields}
                  continueFromCurrentOutcome={continueFromCurrentOutcome}
                  generateGoalCandidates={generateGoalCandidates}
                  goalCandidates={goalCandidates}
                  applyGoalCandidate={applyGoalCandidate}
                  saveCandidateToRecent={saveCandidateToRecent}
                  copyText={copyText}
                  onExecute={handleOpenClawExecute}
                  onRefresh={refreshWorkbench}
                  onUseRecommended={resetOpenClawFields}
                  executing={openclawExecuting}
                />

                <OpenClawWorkspaceV2
                  selectedTemplateId={selectedTemplateId}
                  setSelectedTemplateId={setSelectedTemplateId}
                  openclawUrl={openclawUrl}
                  setOpenclawUrl={setOpenclawUrl}
                  openclawIssue={openclawIssue}
                  setOpenclawIssue={setOpenclawIssue}
                  openclawAccountHint={openclawAccountHint}
                  setOpenclawAccountHint={setOpenclawAccountHint}
                  openclawNotice={openclawNotice}
                  setOpenclawNotice={setOpenclawNotice}
                  latestOpenclawSummary={latestOpenclawSummary}
                  recentOpenclawExecutions={recentOpenclawExecutions}
                  hasOpenclawDraft={hasOpenclawDraft}
                  restoreLastOpenClawDraft={restoreLastOpenClawDraft}
                  resetOpenClawFields={resetOpenClawFields}
                  clearOpenClawFields={clearOpenClawFields}
                  handleOpenClawExecute={handleOpenClawExecute}
                  openclawExecuting={openclawExecuting}
                />

                <div className="grid gap-6 xl:grid-cols-2">
                  <TestSummaryCard verifications={verificationItems} />
                  <DeliverySummaryCard
                    artifacts={artifactItems}
                    latestOutcome={detailData?.latest_outcome}
                    onExportJson={exportCurrentResultJson}
                    onExportMarkdown={exportDeliveryMarkdown}
                    onCopySummary={copyDeliverySummary}
                  />
                </div>

                <RecordTabsPanelV2 activeTab={activeTab} setActiveTab={setActiveTab} />

                <RecordContentPanelV2
                  activeTab={activeTab}
                  timelineItems={timelineItems}
                  executionItems={executionItems}
                  artifactItems={artifactItems}
                  verificationItems={verificationItems}
                />
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
