from __future__ import annotations

from pydantic import BaseModel

from app.main import app
from app.services.rule_core import parse_goal
from app.services.openclaw_worker import execute_openclaw_skill


class GoalRequest(BaseModel):
    raw_input: str


@app.post("/goals/parse", tags=["compat"])
def goals_parse(payload: GoalRequest):
    return parse_goal(payload.raw_input)


@app.post("/openclaw/test", tags=["compat"])
def openclaw_test():
    return execute_openclaw_skill("ping", {"message": "hello from autofabric"})
